const URL="http://localhost:9036/api/paesirandom";

let Username= "";
let elUsername = document.querySelector("#elUsername");
let paesi=[];
let domanda="";
let risultati="";
let punteggio=0;


function prendiProdotti(){

    Username=localStorage.getItem("Username");
    elUsername.innerHTML = Username;
   
    paesi=[];
    why.innerHTML="";
    domanda="";
    risultati="";

    fetch(URL)    
    .then(ris=>{
        
        return ris.json();
    })
    .then(dati=>{
        let numrandom=Math.floor(Math.random()*2);
        domanda=dati[numrandom];

        dati.forEach(obj => {
            paesi.push(obj.paese);
        });
        for(i=0; i<dati.length; i++){
            risp[i].value=dati[i].paese;
            labs[i].textContent = dati[i].paese;
        }
        why.innerHTML+=`<img src="http://localhost:9036/img/${domanda.alpha2Code}.png" >`
        });
}  
let focus = document.querySelector("#focus");  

function controllo(){
    focus.innerHTML="";
    try {
        let risp = document.querySelector("input[type=radio][name=risp]:checked").value;
        
        
        if (risp == null) {                    //controllo se hai risposte
            focus.innerHTML += "<p>non hai selezionato nessuna risposta</p>"
            return false;        
        }else{
            focus.innerHTML = "";
            risp =  document.querySelector("input[type=radio][name=risp]:checked").value;
        if(domanda.paese==risp){       //controllo se hai risposto giusto
            focus.innerHTML+=`<p>hai indovinato +1</p>`;
            punteggio++;
            punt.innerHTML=`<p>Punteggio ${punteggio}</p>`;
            
        }else{
            focus.innerHTML+=`<p>non hai indovinato</p>`
        }
        //dovrebbe resettare i campi input
        document.getElementById('btnnext').addEventListener('click', function () {
            ["risp0", "risp1", "risp2"].forEach(function(id) {                  
                document.getElementById(id).checked = false;
            });
            
        });
        
        return true;
        }
        
    } catch (error) {
        focus.innerHTML += "<p>non hai selezionato nessuna risposta</p>"
    }
    }
function bottone(){
    
    
    let checked = controllo();
    if(checked) prendiProdotti();
    
    
}

function resetMemoria(){
        localStorage.clear();
        location.href="./welcome.html";
    }      

let risp = document.querySelectorAll('input[name="risp"]');

let labs = document.querySelectorAll("label");



let btnfine=document.querySelector("#btnfine")
let why=document.querySelector("#why");
let btnnext=document.querySelector("#btnnext");
let btnrispondi=document.querySelector('#btnrispondi');

window.addEventListener("DOMContentLoaded",prendiProdotti)

btnnext.addEventListener('click',bottone);
btnfine.addEventListener('click',resetMemoria);